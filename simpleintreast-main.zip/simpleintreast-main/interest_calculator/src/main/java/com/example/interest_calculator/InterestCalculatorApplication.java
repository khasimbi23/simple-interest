package com.example.interest_calculator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = "com.example.interest_calculator")

public class InterestCalculatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(InterestCalculatorApplication.class, args);
	}

}