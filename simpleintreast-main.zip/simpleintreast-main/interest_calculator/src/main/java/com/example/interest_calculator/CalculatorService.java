package com.example.interest_calculator;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
@Component
public class CalculatorService {
    private final InterestCalculator calObj;

    public CalculatorService(InterestCalculator calObj) {
        this.calObj = calObj;
    }

    public double calculateInterest(double p, double r, double t)
    {
        return(calObj.calculate(p, r, t));

    }
}