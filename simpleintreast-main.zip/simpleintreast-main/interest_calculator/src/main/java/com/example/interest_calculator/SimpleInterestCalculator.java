package com.example.interest_calculator;

//import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class SimpleInterestCalculator implements InterestCalculator
{

    @Override
    public double calculate(double principle, double rate, double time) {
        // TODO Auto-generated method stub

        return (principle*rate*time/100);
    }
    
}