package com.example.interest_calculator;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/interest")
public class CalculatorController {

    private final CalculatorService calService;

    public CalculatorController(CalculatorService calService) {
        this.calService = calService;
    }

    @GetMapping("/simple")
    public double calculateSimpleInterest(@RequestParam double principal, @RequestParam double rate, @RequestParam double time) 
	{
        return calService.calculateInterest(principal, rate, time);
    }
}