package com.example.interest_calculator;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Component
@Service
public interface InterestCalculator {
    double calculate(double principal, double rate, double time);
}

